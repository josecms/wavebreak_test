<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">
</head>
<body>
    <div class="container">
     
        <div><h4>Calculate a new Payslip</h4></div>
        {!! Form::open(array('action' => 'PayslipController@store', 'id'=>'payslip')) !!}
            <div class="form-group col-sm-2">
                {!! Form::label('first_name', 'First Name :') !!}
                {!! Form::text('first_name', null, ['class'=>'form-control', 'placeholder'=>'Here first name']) !!}
            </div>

            <div class="form-group col-sm-2">
                {!! Form::label('last_name', 'Last Name :') !!}
                {!! Form::text('last_name', null,  ['class'=>'form-control', 'placeholder'=>'Here last name']) !!}
            </div>

            <div class="form-group col-sm-2">
                {!! Form::label('annual_salary', 'Annual Salary :') !!}
                {!! Form::text('annual_salary', null,  ['class'=>'form-control', 'placeholder'=>'Annual Salary']) !!}
            </div>
            <div class="form-group col-sm-2">
                {!! Form::label('pension_rate', 'Pension Rate 0 - 50%:') !!}
                {!! Form::text('pension_rate', null,  ['class'=>'form-control', 'placeholder'=>'Pension Rate']) !!}
            </div>
             <div class="form-group col-sm-2">
                {!! Form::label('payment_start_date', 'Payment period :') !!}
                {!! Form::select('payment_start_date', ['January' => 'January', 'February' => 'February', 'March' => 'March', 'April' => 'April','May' => 'May','June' => 'June','July' => 'July','August' => 'August','Septemper' => 'Septemper','October' => 'October','November' => 'November','December' => 'December'],  'March', ['class' => 'form-control' ]) !!}
            </div>
            <br>
            <div class="form-group col-sm-10 btn">
                {!! Form::submit( 'Submit', ['class'=>'btn btn-primary']) !!} <button class="btn btn-default pull-right"><a href="/payslip">Back</a></button>
            </div>
        {!! Form::close() !!}
        <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
        <script>
        // just for the demos, avoids form submit
        jQuery.validator.setDefaults({
          debug: true,
          success: "valid"
        });
        $( "#payslip" ).validate({
          rules: {
            annual_salary: {
              required: true,
              number: true,
              min:1
            },
            pension_rate: {
              required: true,
              number: true,
              min:0,
              max: 50
            },
            first_name: {
              required: true
            },
            last_name: {
              required: true
            }
          }
        });
        </script>
        
        @if($errors->any())
            <ul class="alert alert-danger">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        @endif

    </div>
</body>
</html>