<?php $__env->startSection('main'); ?>
<head>
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.1/css/bootstrap-combined.min.css" rel="stylesheet">
</head>
    <body>
    <h4>payslips</h4>
    </br>
    </br>
    <div >
    <table class="table table-striped table-bordered table-condensed">
        <thead class="table-active">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Pay period</th>
                <th>Annual Salary</th>
                <th>Gross Income</th>
                <th>Income Tax</th>
                <th>Net Income</th>
                <th>Super</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach( $allPayslips as $payslip ): ?>
            <tr>
                <td></td>
                <td><?php echo e($payslip->first_name); ?> <?php echo e($payslip->last_name); ?></td>
                <td><?php echo e($payslip->pay_period); ?></td>
                <td><?php echo e(number_format($payslip->annual_salary,2)); ?></td>
                <td><?php echo e(number_format($payslip->income_tax,2)); ?></td>
                <td><?php echo e($payslip->gross_income); ?></td>
                <td><?php echo e($payslip->net_income); ?></td>
                <td><?php echo e($payslip->pension_contribuition); ?></td>
                
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    </div>
<a href="<?php echo e(route('payslip.create')); ?>"><p><input class="btn btn-primary col-xs-2" type="submit" value="new Paylisp" /></p></a>
<?php if($allPayslips->count()): ?>  
<?php else: ?>
    There are no payslips generated
<?php endif; ?>
