<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payslip extends Model
{
    protected $table = 'payslip_info_employee';
	protected $fillable = [
        'first_name',
        'last_name',
        'annual_salary',
        'pension_rate',
        'payment_start_date',
        'pay_period',
        'gross_income',
        'income_tax',
        'net_income',
        'pension_contribuition',
        'created_at'
    ];
}
