<?php

namespace App\Http\Controllers;

use App\Http\Requests\PayslipRequest;
use App\Http\Controllers\Controller;
use App\Payslip;
use Illuminate\Http\Request;

class PayslipController extends Controller
{
    //

	public function index()
	{
        //Select all records from Payslip_info_employee table via Payslip method
		$allPayslips = Payslip::all();    //Eloquent ORM method to return all matching results
		
        //Redirecting to payslipList.blade.php with $allPayslips  
        return View('payslips.payslipList', compact('allPayslips'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		//Redirecting to generatePayslip.blade.php 
		return view('payslips.generatePayslip');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store(PayslipRequest $requestData)
	{
		//Insert Query
        $payslip = new Payslip;
        $payslip->first_name= $requestData['first_name'];
        $payslip->last_name= $requestData['last_name'];
        $payslip->payment_start_date= $requestData['payment_start_date'];
        $annual_salary = $payslip->annual_salary= $requestData['annual_salary'];
        $pension_rate = $payslip->pension_rate= $requestData['pension_rate'] / 100;
        
        //
        $payslipController = new PayslipController;
        $checkSalary = $payslipController->calculatePayslip($annual_salary, $pension_rate);
        //
        
        $payslip->annual_salary = $annual_salary;
        $payslip->pension_rate = $payslip->pension_rate= $requestData['pension_rate'];
        $payslip->pay_period = $payslip->payment_start_date;
        $payslip->gross_income = $checkSalary['gross_income'];
        $payslip->income_tax = $checkSalary['income_tax'];
        $payslip->net_income = $checkSalary['net_income'];
        $payslip->pension_contribuition = $checkSalary['pension_contribuition'];
        $payslip->created_at = date_create();
        $payslip->save();

        //Send control to index() method where it'll redirect to payslipList.blade.php
        return redirect()->route('payslip.index');
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//Get results by targeting id
        $payslip = Payslip::find($id);

        //Redirecting to showPayslip.blade.php with $payslip variable
        return view('payslips.showPayslip')->with('payslip',$payslip);
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//Get results by targeting id
        $payslip = Payslip::find($id);

        //Redirecting to showPayslip.blade.php with $payslip variable
        return view('payslips.editPayslip')->with('payslip',$payslip);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id, PayslipRequest $requestData)
	{
		$payslip = Payslip::find($id);
		
		$payslip->first_name= $requestData['first_name'];
        $payslip->last_name= $requestData['last_name'];
        $payslip->payment_start_date= $requestData['payment_start_date'];
        $annual_salary = $payslip->annual_salary= $requestData['annual_salary'];
        $pension_rate = $payslip->pension_rate= $requestData['pension_rate'] / 100;
        
        //
        $payslipController = new PayslipController;
        $checkSalary = $payslipController->calculatePayslip($annual_salary, $pension_rate);
        //
        
        $payslip->annual_salary = $annual_salary;
        $payslip->pension_rate = $payslip->pension_rate= $requestData['pension_rate'];
        $payslip->pay_period = $payslip->payment_start_date;
        $payslip->gross_income = $checkSalary['gross_income'];
        $payslip->income_tax = $checkSalary['income_tax'];
        $payslip->net_income = $checkSalary['net_income'];
        $payslip->pension_contribuition = $checkSalary['pension_contribuition'];
        $payslip->created_at = date_create();
        $payslip->save();

        //Send control to index() method where it'll redirect to payslipList.blade.php
        return redirect()->route('payslip.index');
		
		
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//find result by id and delete 
        Payslip::find($id)->delete();

        //Redirecting to index() method
        return redirect()->route('payslip.index');
	}
	
	public function calculatePayslip($annual_salary, $pension_rate ){
	    
	     //Check income tax for the annual salary
        if($annual_salary <= '18200'){
            
            $tax_over = 0;
            $tax = 0;
            $plus_tax = 0;
            
            $gross_income = round($annual_salary / 12);
            $income_tax = 0;
            $net_income = 0;
            $pension_contribuition = round($gross_income * $pension_rate);
            $result = array('gross_income' => $gross_income,'income_tax' => $income_tax,'net_income' => $net_income,'pension_contribuition' => $pension_contribuition );
	    
	        return $result;
            
        }elseif($annual_salary >= '18201' && $annual_salary <= '37000') {
                        
            $tax_over = 18000;
            $tax = 0;
            $plus_tax = 0.19;
            
        }elseif($annual_salary >= '37001' && $annual_salary <= '80000') {
            
            $tax_over = 37000;
            $tax = 3572;
            $plus_tax = 0.325;
    
        }elseif($annual_salary >= '80001' && $annual_salary <= '180000') {
            
            $tax_over = 80000;
            $tax = 17547;
            $plus_tax = 0.37;
            
        }else{
            
            $tax_over = 180000;
            $tax = 54547;
            $plus_tax = 0.45;
        }
	   
            $gross_income = round($annual_salary / 12);
            $income_tax = round(($tax + ($annual_salary - $tax_over) * $plus_tax ) / 12);
            $net_income = $gross_income - $income_tax;
            $pension_contribuition = round($gross_income * $pension_rate);
            $result = array('gross_income' => $gross_income,'income_tax' => $income_tax,'net_income' => $net_income,'pension_contribuition' => $pension_contribuition );
    	    
    	    return $result;
	}
	
}